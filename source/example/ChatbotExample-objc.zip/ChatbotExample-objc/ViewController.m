//
//  ViewController.m
//  ChatbotExample-objc
//
//  Created by Pawel Zebrowski on 2018-11-19.
//  Copyright © 2018 InContext.ai. All rights reserved.
//

#import "ViewController.h"
#import <ChatbotSDK/ChatbotSDK.h>

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextView *textView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    ChatBot *chatbot = [[ChatBot alloc] initWithUsername:@"username" password:@"password"];
    [chatbot connectOnConnectSuccess:^(LoginStatus * _Nonnull loginStatus) {
        [chatbot activateOnConnect:^{
            //connected and listening
            [chatbot enableSpeaker];
        } onDisconnect:^{
            //disconnected
        } onError:^{
            //error
        } onPartialResult:^(NSString * _Nonnull partial) {
            //partial speech recognized
        } onResult:^(Interaction * _Nullable interaction) {
            self.textView.text = [self.textView.text stringByAppendingString:[NSString stringWithFormat:@"Doctor: %@\n", interaction.display_as]];
            self.textView.text = [self.textView.text stringByAppendingString:[NSString stringWithFormat:@"Bot: %@\n", interaction.response ?: @""]];
        }];
    } onConnectError:^(LoginStatus * _Nonnull loginStatus) {
        //connection error
    }];
}

@end
