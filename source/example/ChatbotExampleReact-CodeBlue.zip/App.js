import React, {Component} from 'react';
import {StyleSheet, Text, ScrollView} from 'react-native';
import {CodeBlueBot} from 'react-native-chatbot-sdk';

type Props = {};
export default class App extends Component<Props> {
    constructor() {
        super();
        this.state = {
            log: '\n'
        }

        CodeBlueBot.initialize("username", "password");

        CodeBlueBot.connect((error, loginStatus) => {
            if (loginStatus.success) {
                var connectTime = null
                CodeBlueBot.activate(
                    //onConnect
                    (error, text) => {
                        this.log("Connected")
                        connectTime = new Date()
                    },
                    //onDisconnect
                    (error, text) => {
                        this.log("Disconnected")
                    },
                    //onError
                    (error, text) => {
                        this.log("Error")
                    },
                    //onResult
                    (error, interactionJson) => {
                        var interaction = JSON.parse(interactionJson);
                        if (interaction.action != null) {
                            for (var action of interaction.action) {
                                var actionTime = new Date(connectTime.getTime())
                                actionTime.setMilliseconds(actionTime.getMilliseconds() + action.timestamp)
                                var timestamp = actionTime.getHours() + ':' + actionTime.getMinutes() + ':' + actionTime.getSeconds();
                                this.log(timestamp + ": " + action.command);
                                if (action.arguments_kv != null) {
                                    for (const [k, v] of Object.entries(action.arguments_kv)) {
                                        this.log('  ' + k + ': ' + v);
                                    }
                                }
                                this.log('');
                            }
                        }
                    });
            } else {
                console.log(loginStatus.error)
            }
        });
    }

    log(text) {
        this.setState({
            log: this.state.log + text + '\n'
        });
    }

    render() {
        return (
            <ScrollView
                style={styles.container}
                ref={ref => this.scrollView = ref}
                onContentSizeChange={(contentWidth, contentHeight)=>{
                    this.scrollView.scrollToEnd({animated: true});
                }}>
                <Text style={styles.instructions}>{this.state.log}</Text>
            </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5FCFF',
    },
    instructions: {
        textAlign: 'left',
        color: '#333333',
        marginBottom: 5,
    },
});