//
//  ViewController.swift
//  ChatbotExample
//
//  Created by Pawel Zebrowski on 2018-11-15.
//  Copyright © 2018 InContext.ai. All rights reserved.
//

import UIKit
import ChatbotSDK

class ViewController: UIViewController {
    
    @IBOutlet weak var textView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let chatbot = ChatBot(username: "username", password: "password")
        chatbot.connect(onConnectSuccess: { (loginStatus) in
            chatbot.activate(onConnect: {
                //connected and listening
                chatbot.enableSpeaker() //enable reading out of response
            }, onDisconnect: {
                //disconnected
            }, onError: {
                //error
            }, onPartialResult: { (partial) in
                //partial speech recognized
            }, onResult: { (interaction) in
                self.textView.text.append("Doctor: \(interaction!.display_as!)\n")
                self.textView.text.append("Bot: \(interaction!.response ?? "nil")\n")
            })
        }, onConnectError: { (loginStatus) in
            //connection error
        })
    }
}
