//
//  RNChatbotSDK.swift
//  ChatbotExampleReact
//
//  Created by Pawel Zebrowski on 2019-02-09.
//  Copyright © 2019 inContext.ai. All rights reserved.
//

import Foundation
import ChatbotSDK

@objc(RNChatBot)
class RNChatBot: RCTEventEmitter {
    
    var chatbot: ChatBot?
    var hasListeners = false
    
    @objc func initialize(_ username: String, password: String) -> Void {
        chatbot = ChatBot(username: username, password: password)
    }
    
    @objc func initialize(_ apiKey: String) -> Void {
        chatbot = ChatBot(apiKey)
    }
    
    @objc func connect(_ callback: @escaping RCTResponseSenderBlock) {
        self.chatbot?.connect(
            onConnectSuccess: {
                loginStatus in
                
                callback([NSNull(), ["success": true]])
            },
            onConnectError: {
                loginStatus in
                
                callback([NSError(), ["success": false, "error": loginStatus.errorMessage]])
            })
    }
    
    @objc func activate() {
        self.chatbot?.activate(onConnect: {
            self.sendEvent(withName: "onConnect", body: nil)
        }, onDisconnect: {
            self.sendEvent(withName: "onDisconnect", body: nil)
        }, onError: {
            self.sendEvent(withName: "onError", body: nil)
        }, onPartialResult: { (partialResult) in
            self.sendEvent(withName: "onPartialResult", body: partialResult)
        }, onResult: { (interaction) in
            self.sendEvent(withName: "onResult", body: String(data: try! JSONEncoder().encode(interaction), encoding: .utf8))
        })
    }
    
    @objc func deactivate() {
        chatbot?.deactivate()
    }
    
    @objc func enableSpeaker() {
        chatbot?.enableSpeaker()
    }
    
    @objc func disableSpeaker() {
        chatbot?.disableSpeaker()
    }
    
    override static func requiresMainQueueSetup() -> Bool {
        return false
    }
    
    override func supportedEvents() -> [String]! {
        return ["onConnect", "onDisconnect", "onError", "onPartialResult", "onResult"]
    }
    
    override func startObserving()
    {
        hasListeners = true
    }
    
    override func stopObserving()
    {
        hasListeners = false
    }
}

@objc(RNCodeBlueBot)
class RNCodeBlueBot: RCTEventEmitter {
    
    var codeBlueBot: CodeBlueBot?
    var hasListeners = false
    
    @objc func initialize(_ username: String, password: String) -> Void {
        codeBlueBot = CodeBlueBot(username: username, password: password)
    }
    
    @objc func connect(_ callback: @escaping RCTResponseSenderBlock) {
        self.codeBlueBot?.connect(
            onConnectSuccess: {
                loginStatus in
                
                callback([NSNull(), ["success": true]])
        },
            onConnectError: {
                loginStatus in
                
                callback([NSError(), ["success": false, "error": loginStatus.errorMessage]])
        })
    }
    
    @objc func activate() {
        self.codeBlueBot?.activate(onConnect: {
            self.sendEvent(withName: "onConnect", body: nil)
        }, onDisconnect: {
            self.sendEvent(withName: "onDisconnect", body: nil)
        }, onError: {
            self.sendEvent(withName: "onError", body: nil)
        }, onResult: { (interaction ) in
            self.sendEvent(withName: "onResult", body: String(data: try! JSONEncoder().encode(interaction), encoding: .utf8))
        })
    }
    
    @objc func deactivate() {
        codeBlueBot?.deactivate()
    }
    
    override static func requiresMainQueueSetup() -> Bool {
        return false
    }
    
    override func supportedEvents() -> [String]! {
        return ["onConnect", "onDisconnect", "onError", "onResult"]
    }
    
    override func startObserving()
    {
        hasListeners = true
    }
    
    override func stopObserving()
    {
        hasListeners = false
    }
}
