//
//  ChatbotExampleReact-Bridging-Header.h
//  ChatbotExampleReact
//
//  Created by Pawel Zebrowski on 2019-02-08.
//  Copyright © 2019 inContext.ai. All rights reserved.
//

#ifndef ChatbotExampleReact_Bridging_Header_h
#define ChatbotExampleReact_Bridging_Header_h
#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

#endif /* ChatbotExampleReact_Bridging_Header_h */
