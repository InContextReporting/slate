//
//  RNChatbotSDK.m
//  ChatbotExampleReact
//
//  Created by Pawel Zebrowski on 2019-02-09.
//  Copyright © 2019 inContext.ai. All rights reserved.
//

#import <React/RCTBridgeModule.h>
#import "React/RCTEventEmitter.h"

@interface RCT_EXTERN_MODULE(RNChatBot, RCTEventEmitter)

RCT_EXTERN_METHOD(initialize:(NSString *)username password:(NSString *)password)

RCT_EXTERN_METHOD(connect: (RCTResponseSenderBlock *)callback)

RCT_EXTERN_METHOD(activate)

RCT_EXTERN_METHOD(deactivate)

RCT_EXTERN_METHOD(enableSpeaker)

RCT_EXTERN_METHOD(disableSpeaker)

@end

@interface RCT_EXTERN_MODULE(RNCodeBlueBot, RCTEventEmitter)

RCT_EXTERN_METHOD(initialize:(NSString *)username password:(NSString *)password)

RCT_EXTERN_METHOD(connect: (RCTResponseSenderBlock *)callback)

RCT_EXTERN_METHOD(activate)

RCT_EXTERN_METHOD(deactivate)

@end
