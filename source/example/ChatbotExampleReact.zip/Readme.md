# ChatbotExampleReact

## Installation

From the project root:
```
npm install
```

From ./ios/
```
pod install
```

## Run

From the project root:
```
react-native run-ios
```