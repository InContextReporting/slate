import React, {Component} from 'react';
import {StyleSheet, Text, ScrollView} from 'react-native';
import {ChatBot} from 'react-native-chatbot-sdk';

type Props = {};
export default class App extends Component<Props> {
    constructor() {
        super();
        this.state = {
            log: '\n'
        }

        ChatBot.initialize("username", "password");

        ChatBot.connect((error, loginStatus) => {
            if (loginStatus.success) {
                ChatBot.activate(
                    //onConnect
                    (error, text) => {
                        this.log("Connected")
                        ChatBot.enableSpeaker()
                    },
                    //onDisconnect
                    (error, text) => {
                        //disconnected
                    },
                    //onError
                    (error, text) => {
                        //error
                    },
                    //onPartialResult
                    (error, partial) => {
                        //partial speech recognized
                    },
                    //onResult
                    (error, interactionJson) => {
                        var interaction = JSON.parse(interactionJson);
                        this.log("Doctor: " + interaction.display_as);
                        this.log("Bot: " + interaction.response);
                    });
            } else {
                //connection error
            }
        });
    }

    log(text) {
        this.setState({
            log: this.state.log + text + '\n'
        });
    }

    render() {
        return (
            <ScrollView
                style={styles.container}
                ref={ref => this.scrollView = ref}
                onContentSizeChange={(contentWidth, contentHeight)=>{
                    this.scrollView.scrollToEnd({animated: true});
                }}>
                <Text style={styles.instructions}>{this.state.log}</Text>
            </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5FCFF',
    },
    instructions: {
        textAlign: 'left',
        color: '#333333',
        marginBottom: 5,
    },
});